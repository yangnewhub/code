// Copyright 2024 The Go Authors. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

// Code generated with somegen DO NOT EDIT.

package testdata

type T struct {
	x, y int
}

var _ = [42]T{
	T{}, // No simplification fix is offered in generated code.
	T{1, 2}, // No simplification fix is offered in generated code.
	T{3, 4}, // No simplification fix is offered in generated code.
}
