#pragma once 
#include "ThreadCache.h"

static void* AllocMemory(int size)
{
	assert(size > 0);

	if (threadCache == nullptr)
	{
		threadCache = new ThreadCache;
	}

	return threadCache->New(size);
}

static void DeleteMemory(void* ptr, int size)
{
	assert(ptr);
	assert(size > 0);

	threadCache->Delete(ptr, size);

}